"""KiCad PCM entry point: put the bundled package on the path and register.

KiCad imports this file from the installed plugins directory. We add this folder
to sys.path so ``import finish3d`` resolves to the bundled package, then import
the action plugin, which registers the "Finish 3D" toolbar button on import.
"""

import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

try:
    import finish3d.kicad_action  # noqa: F401  (registers the ActionPlugin)
except Exception:  # pragma: no cover - surface load errors in KiCad's log
    import traceback
    traceback.print_exc()
